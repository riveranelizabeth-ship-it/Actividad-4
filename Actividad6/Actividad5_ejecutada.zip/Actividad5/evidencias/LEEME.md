# Capturas reales pendientes

El seguimiento exportado es real, pero no sustituye las capturas solicitadas.
1. Vista del experimento mostrando los dos runs padre y sus hijos.
2. Comparación de métricas y parámetros de ambos modelos.
3. Detalle de un run con los SHA256 de datos, parámetros y artefacto modelo.

Guardar aquí 01_experimentos.png, 02_comparacion.png y 03_modelo.png. No incluir credenciales.
Abrir panel mediante la celda 7 del notebook; o restaurar el ZIP de seguimiento con fuentes/restaurar_mlflow.py y usar mlflow ui.
